# Your Favicon Package

This package was generated with [RealFaviconGenerator](https://realfavicongenerator.net/) [v0.16](https://realfavicongenerator.net/change_log#v0.16)

## Install instructions

To install this package:

Extract this package in the root of your web site. If your site is <code>http://www.example.com</code>, you should be able to access a file named <code>http://www.example.com/favicon.ico</code>.

Insert the following code in the `head` section of your pages:

    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#1abc9c">
    <meta name="apple-mobile-web-app-title" content="Portfolio">
    <meta name="application-name" content="Portfolio">
    <meta name="msapplication-TileColor" content="#1abc9c">
    <meta name="theme-color" content="#ecf0f1">

*Optional* - Check your favicon with the [favicon checker](https://realfavicongenerator.net/favicon_checker)